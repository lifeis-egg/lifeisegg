/** API 키 없이 사용하는 지도 링크·임베드 URL */
export function getMapDirectionsLinks(address: string) {
  const q = encodeURIComponent(address);
  return {
    kakao: `https://map.kakao.com/link/search/${q}`,
    naver: `https://map.naver.com/v5/search/${q}`,
    google: `https://www.google.com/maps/search/?api=1&query=${q}`,
  };
}

/** Google Maps iframe embed (Share 없이 주소 검색형 — 별도 API 키 불필요) */
export function getGoogleMapEmbedUrl(address: string) {
  return `https://www.google.com/maps?q=${encodeURIComponent(address)}&hl=ko&z=16&output=embed`;
}
