import type { LucideIcon } from "lucide-react";
import {
  BrainCircuit,
  Database,
  GraduationCap,
  Layers,
} from "lucide-react";

import {
  solutionCategoryOrder,
  solutions,
  type SolutionItem,
} from "@/config/home-content";

export const categoryIcons = {
  edutech: GraduationCap,
  data: Database,
  si: Layers,
  ai: BrainCircuit,
} satisfies Record<SolutionItem["category"], LucideIcon>;

export function getSolutionsByCategory(category: SolutionItem["category"]) {
  return solutions.filter((s) => s.category === category);
}

export { solutionCategoryOrder, solutions };
export type { SolutionItem };
