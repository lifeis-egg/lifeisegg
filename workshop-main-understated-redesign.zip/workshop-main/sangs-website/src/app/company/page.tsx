import type { Metadata } from "next";

import {
  CompanyCertificationsSection,
  CompanyHistorySection,
  CompanyLocationsSection,
  CompanyMainBusinessSection,
  CompanyOverviewSection,
  CompanyPageCta,
  CompanyPillarsSection,
} from "@/components/company/company-sections";
import { SubpageHero } from "@/components/layout/subpage-hero";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "기업정보",
  description: `${siteConfig.name} — 설립 2005, EduTech·Data·SI·AI IT 기업 소개, 연혁, 인증, 오시는 길`,
  openGraph: {
    title: `기업정보 | ${siteConfig.shortName}`,
  },
};

export default function CompanyPage() {
  return (
    <>
      <SubpageHero
        breadcrumbLabel="기업정보"
        eyebrow="Company"
        title={
          <>
            교육과 데이터,
            <span className="text-primary"> 20년의 기술력</span>
          </>
        }
        description="LMS 창업 1세대 기업에서 AI·데이터 플랫폼 기업으로 — 상상스토리의 비전, 연혁, 인증을 소개합니다."
      />
      <div className="mx-auto max-w-7xl space-y-16 px-4 py-12 sm:px-6 lg:space-y-20 lg:px-8 lg:py-16">
        <CompanyOverviewSection />
        <CompanyPillarsSection />
        <CompanyMainBusinessSection />
        <CompanyHistorySection />
        <CompanyCertificationsSection />
        <CompanyLocationsSection />
        <CompanyPageCta />
      </div>
    </>
  );
}
