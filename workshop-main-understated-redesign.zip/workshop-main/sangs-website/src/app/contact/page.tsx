import type { Metadata } from "next";

import {
  ContactInfoPanel,
  ContactInquiryForm,
} from "@/components/contact/contact-inquiry-form";
import { SubpageHero } from "@/components/layout/subpage-hero";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "도입 문의",
  description: `${siteConfig.shortName} 솔루션 도입·상담 및 브로슈어 요청`,
  openGraph: {
    title: `도입 문의 | ${siteConfig.shortName}`,
  },
};

export default function ContactPage() {
  return (
    <>
      <SubpageHero
        breadcrumbLabel="도입 문의"
        eyebrow="Contact"
        title={
          <>
            솔루션 도입·
            <span className="text-primary">상담 신청</span>
          </>
        }
        description="LMS, 데이터 플랫폼, SI/SM, AI 엔진 도입부터 유지보수까지. 담당 컨설턴트가 요구사항에 맞는 제안을 드립니다."
      />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-14 lg:px-8 lg:py-16">
        <ContactInfoPanel />
        <ContactInquiryForm />
      </div>
    </>
  );
}
