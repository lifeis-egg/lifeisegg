import type { Metadata } from "next";

import { LocationMapSection } from "@/components/contact/location-map-section";
import { SubpageHero } from "@/components/layout/subpage-hero";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "오시는 길",
  description: `${siteConfig.shortName} 서울 본사, 세종 개발실, 미국 지사 위치 안내`,
  openGraph: {
    title: `오시는 길 | ${siteConfig.shortName}`,
  },
};

export default function ContactMapPage() {
  return (
    <>
      <SubpageHero
        breadcrumbLabel="오시는 길"
        eyebrow="Location"
        title={
          <>
            <span className="text-primary">오시는 길</span>
          </>
        }
        description="서울 본사·세종 개발실·미국 지사 위치입니다. 지도에서 바로 길찾기를 이용할 수 있습니다."
      />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <LocationMapSection />
      </div>
    </>
  );
}
