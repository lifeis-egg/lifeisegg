import { ClientReferenceSection } from "@/components/sections/client-reference-section";
import { HeroSection } from "@/components/sections/hero-section";
import { SolutionsGridSection } from "@/components/sections/solutions-grid-section";

export default function Home() {
  return (
    <>
      <HeroSection />
      <ClientReferenceSection />
      <SolutionsGridSection />
    </>
  );
}
