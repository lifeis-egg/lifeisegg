import type { Metadata } from "next";

import { SubpageHero } from "@/components/layout/subpage-hero";
import {
  PortfolioReferenceList,
  PortfolioStats,
} from "@/components/portfolio/portfolio-sections";
import { references } from "@/config/references-content";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "사업실적",
  description: `${siteConfig.shortName} 에듀테크·데이터·정보화·콘텐츠 레퍼런스 ${references.length}건`,
  openGraph: {
    title: `사업실적 | ${siteConfig.shortName}`,
  },
};

export default function PortfolioPage() {
  return (
    <>
      <SubpageHero
        breadcrumbLabel="사업실적"
        eyebrow="References"
        title={
          <>
            <span className="text-primary">레퍼런스</span>
          </>
        }
        description="에듀테크, 데이터, 정보화, 콘텐츠 분야 수행 실적을 분야별로 확인하실 수 있습니다."
      />
      <div className="mx-auto max-w-7xl space-y-12 px-4 py-12 sm:px-6 lg:space-y-14 lg:px-8 lg:py-16">
        <PortfolioStats />
        <PortfolioReferenceList />
      </div>
    </>
  );
}
