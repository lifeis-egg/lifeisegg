import type { Metadata } from "next";

import { BusinessHero } from "@/components/business/business-hero";
import {
  BusinessCertifications,
  BusinessCtaBand,
} from "@/components/business/business-bottom-blocks";
import { BusinessSolutionSections } from "@/components/business/business-solution-sections";
import {
  BusinessMobileNav,
  BusinessStickyNav,
} from "@/components/business/business-sticky-nav";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "사업분야",
  description:
    "SS-LMS, SS-COLLECTOR, SS-META, SS-DQ, SS-ML, SS-Portal, SS-AI Engine — 상상스토리 EduTech·Data·SI/SM·AI 솔루션 상세",
  openGraph: {
    title: `사업분야 | ${siteConfig.shortName}`,
    description: siteConfig.description,
  },
};

export default function BusinessPage() {
  return (
    <>
      <BusinessHero />
      <BusinessMobileNav />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:flex lg:gap-12 lg:px-8 lg:py-16">
        <aside className="hidden w-56 shrink-0 lg:block">
          <BusinessStickyNav />
        </aside>
        <div className="min-w-0 flex-1 space-y-16">
          <BusinessSolutionSections />
          <BusinessCertifications />
          <BusinessCtaBand />
        </div>
      </div>
    </>
  );
}
