import type { Metadata } from "next";

import { SubpageHero } from "@/components/layout/subpage-hero";
import {
  SupportChannelsSection,
  SupportDownloadsSection,
  SupportFaqSection,
  SupportProcessSection,
  SupportQuickBar,
} from "@/components/support/support-sections";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = {
  title: "고객지원",
  description: `${siteConfig.shortName} FAQ, 자료실, 영업·SM 지원 채널 안내`,
  openGraph: {
    title: `고객지원 | ${siteConfig.shortName}`,
  },
};

export default function SupportPage() {
  return (
    <>
      <SubpageHero
        breadcrumbLabel="고객지원"
        eyebrow="Support"
        title={
          <>
            도입부터 운영까지,
            <span className="text-primary"> 함께하는 지원</span>
          </>
        }
        description="솔루션 문의, 기술·SM 지원, 브로슈어 요청까지 — 채널별로 빠르게 연결해 드립니다."
      />
      <div className="mx-auto max-w-7xl space-y-16 px-4 py-12 sm:px-6 lg:space-y-20 lg:px-8 lg:py-16">
        <SupportQuickBar />
        <SupportChannelsSection />
        <SupportProcessSection />
        <SupportFaqSection />
        <SupportDownloadsSection />
      </div>
    </>
  );
}
