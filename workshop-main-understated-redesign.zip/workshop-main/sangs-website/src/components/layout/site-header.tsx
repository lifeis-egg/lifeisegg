"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Menu } from "lucide-react";

import { mainNav, siteConfig } from "@/config/site";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 18);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={cn(
      "sticky top-0 z-50 w-full border-b transition-[background-color,box-shadow,border-color] duration-300",
      scrolled ? "border-border bg-background/95 shadow-sm" : "border-border/70 bg-background/90 backdrop-blur-sm"
    )}>
      <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between gap-5 px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex shrink-0 items-center gap-2.5">
          <span className="flex size-8 items-center justify-center rounded-md bg-primary text-[11px] font-bold text-primary-foreground">SS</span>
          <span className="leading-tight">
            <span className="block text-[15px] font-semibold tracking-[-0.02em] text-foreground">{siteConfig.shortName}</span>
            <span className="hidden text-[10px] font-medium text-muted-foreground sm:block">Sangs Story</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-0.5 md:flex" aria-label="주요 메뉴">
          {mainNav.map((item, index) => (
            <Link key={item.href} href={item.href} className={cn(
              "px-3.5 py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:text-foreground",
              index === 2 && "mr-1"
            )}>{item.title}</Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button nativeButton={false} render={<Link href={siteConfig.contactCta.href} />} className="hidden h-9 rounded-md px-4 text-sm sm:inline-flex">
            {siteConfig.contactCta.label}
          </Button>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger render={<Button variant="outline" size="icon" className="md:hidden" aria-label="메뉴 열기" />}>
              <Menu className="size-5" />
            </SheetTrigger>
            <SheetContent side="right" className="w-[min(100vw-2rem,20rem)]">
              <SheetHeader><SheetTitle>{siteConfig.shortName}</SheetTitle></SheetHeader>
              <nav className="mt-6 flex flex-col gap-1" aria-label="모바일 메뉴">
                {mainNav.map((item) => (
                  <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className="rounded-md px-3 py-3 text-base font-medium text-foreground hover:bg-muted">{item.title}</Link>
                ))}
                <Button nativeButton={false} render={<Link href={siteConfig.contactCta.href} />} className="mt-4 h-11 w-full" onClick={() => setOpen(false)}>{siteConfig.contactCta.label}</Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
