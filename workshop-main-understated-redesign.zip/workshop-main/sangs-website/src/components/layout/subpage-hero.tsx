import Link from "next/link";
import { ChevronRight } from "lucide-react";

type SubpageHeroProps = {
  breadcrumbLabel: string;
  eyebrow: string;
  title: React.ReactNode;
  description: string;
};

export function SubpageHero({
  breadcrumbLabel,
  eyebrow,
  title,
  description,
}: SubpageHeroProps) {
  return (
    <section className="relative overflow-hidden border-b border-border/70 bg-muted/15">
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_70%_50%_at_30%_-10%,var(--brand-glow),transparent)]"
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-4 py-11 sm:px-6 sm:py-14 lg:px-8 lg:py-[68px]">
        <nav
          className="mb-5 flex items-center gap-1 text-xs text-muted-foreground"
          aria-label="breadcrumb"
        >
          <Link href="/" className="transition-colors hover:text-foreground">
            홈
          </Link>
          <ChevronRight className="size-4 opacity-60" aria-hidden />
          <span className="font-medium text-foreground">{breadcrumbLabel}</span>
        </nav>
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-accent">
          {eyebrow}
        </p>
        <h1 className="mt-2 max-w-3xl font-heading text-[2.15rem] font-bold tracking-[-0.035em] text-foreground sm:text-[2.8rem]">
          {title}
        </h1>
        <p className="mt-5 max-w-2xl text-pretty text-[16px] leading-7 text-muted-foreground">
          {description}
        </p>
      </div>
    </section>
  );
}
