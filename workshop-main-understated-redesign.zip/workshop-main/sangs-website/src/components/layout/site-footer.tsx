import Link from "next/link";

import { companyContact, companyOffices } from "@/config/contact";
import { footerNav, siteConfig } from "@/config/site";

export function SiteFooter() {
  const seoul = companyOffices.find((o) => o.id === "seoul");

  return (
    <footer className="mt-auto border-t border-border bg-muted/15">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-start">
          <div className="max-w-md">
            <Link
              href="/"
              className="text-sm font-semibold text-foreground transition-opacity hover:opacity-90"
            >
              {siteConfig.name}
            </Link>
            <p className="mt-2 text-sm text-muted-foreground">
              {siteConfig.description}
            </p>
            {seoul ? (
              <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
                <span className="font-medium text-foreground/80">
                  {seoul.label}
                </span>
                <br />
                {seoul.zip ? `우) ${seoul.zip} · ` : null}
                {seoul.address}
                <br />
                T. {companyContact.phone} · F. {companyContact.fax}
              </p>
            ) : null}
          </div>
          <nav
            className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm sm:grid-cols-3"
            aria-label="푸터 메뉴"
          >
            {footerNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-muted-foreground transition-colors hover:text-foreground"
              >
                {item.title}
              </Link>
            ))}
          </nav>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Sangs Story. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
