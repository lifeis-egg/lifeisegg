import Link from "next/link";
import {
  ArrowRight,
  Download,
  FileText,
  Headphones,
  Mail,
  MapPin,
  Phone,
} from "lucide-react";

import { companyContact } from "@/config/contact";
import { siteConfig } from "@/config/site";
import {
  downloadResources,
  supportChannels,
  supportFaqs,
  supportProcess,
} from "@/config/support-content";
import { SectionHeading } from "@/components/ui/section-heading";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const faqCategoryStyle: Record<
  (typeof supportFaqs)[number]["category"],
  string
> = {
  도입: "bg-primary/10 text-primary",
  기술: "bg-brand-accent/10 text-brand-accent",
  운영: "bg-muted text-muted-foreground",
  자료: "bg-emerald-500/10 text-emerald-800 dark:text-emerald-200",
};

export function SupportChannelsSection() {
  return (
    <section aria-labelledby="channels-heading">
      <SectionHeading
        eyebrow="Contact"
        title="고객 지원 채널"
        description={`${companyContact.businessHours} · 긴급 장애는 계약 SLA에 따라 별도 핫라인을 안내드립니다.`}
      />
      <ul className="mt-10 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {supportChannels.map((channel) => (
          <li
            key={channel.id}
            className="flex flex-col rounded-2xl border border-border/80 bg-card p-6 shadow-sm"
          >
            <Headphones className="size-5 text-brand-accent" aria-hidden />
            <h3 className="mt-4 font-bold text-foreground">{channel.title}</h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {channel.description}
            </p>
            <p className="mt-4 text-sm font-semibold text-foreground">
              {channel.href ? (
                <a href={channel.href} className="hover:text-primary">
                  {channel.contact}
                </a>
              ) : (
                channel.contact
              )}
            </p>
            <Button
              nativeButton={false}
              render={<Link href={channel.action.href} />}
              variant="outline"
              className="mt-5 w-full"
            >
              {channel.action.label}
            </Button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function SupportProcessSection() {
  return (
    <section
      className="rounded-2xl border border-border/80 bg-muted/25 p-8 sm:p-10"
      aria-labelledby="process-heading"
    >
      <h2 id="process-heading" className="text-xl font-bold text-foreground">
        도입 · 지원 프로세스
      </h2>
      <ol className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {supportProcess.map((item) => (
          <li key={item.step}>
            <p className="text-2xl font-bold text-primary/30">{item.step}</p>
            <h3 className="mt-2 font-semibold text-foreground">{item.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{item.detail}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function SupportFaqSection() {
  return (
    <section aria-labelledby="faq-heading">
      <SectionHeading
        eyebrow="FAQ"
        title="자주 묻는 질문"
        description="추가 문의는 도입 문의 또는 대표전화로 연결해 드립니다."
      />
      <div className="mt-10 space-y-3">
        {supportFaqs.map((faq) => (
          <details
            key={faq.id}
            className="group rounded-xl border border-border/80 bg-card px-5 py-4 open:shadow-sm"
          >
            <summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-left font-medium text-foreground marker:content-none [&::-webkit-details-marker]:hidden">
              <span className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3">
                <span
                  className={cn(
                    "w-fit rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase",
                    faqCategoryStyle[faq.category]
                  )}
                >
                  {faq.category}
                </span>
                {faq.question}
              </span>
              <span className="shrink-0 text-muted-foreground transition-transform group-open:rotate-45">
                +
              </span>
            </summary>
            <p className="mt-4 border-t border-border/60 pt-4 text-sm leading-relaxed text-muted-foreground">
              {faq.answer}
            </p>
          </details>
        ))}
      </div>
    </section>
  );
}

export function SupportDownloadsSection() {
  return (
    <section aria-labelledby="downloads-heading">
      <SectionHeading
        eyebrow="Resources"
        title="자료실"
        description="브로슈어는 영업 검토 후 PDF로 제공됩니다. 도입 문의 시 수신 항목을 선택해 주세요."
      />
      <ul className="mt-10 grid gap-4 sm:grid-cols-3">
        {downloadResources.map((resource) => (
          <li
            key={resource.id}
            className="flex flex-col rounded-2xl border border-border/80 bg-card p-5 shadow-sm"
          >
            <FileText className="size-5 text-primary" aria-hidden />
            <h3 className="mt-3 font-semibold text-foreground">
              {resource.title}
            </h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {resource.description}
            </p>
            <p className="mt-3 text-xs font-medium text-muted-foreground">
              {resource.format}
            </p>
            <Button
              nativeButton={false}
              render={<Link href="/contact" />}
              variant="outline"
              size="sm"
              className="mt-4 w-full"
            >
              <Download className="size-4" />
              요청하기
            </Button>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function SupportQuickBar() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Link
        href={companyContact.phoneHref}
        className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/30"
      >
        <Phone className="size-5 text-brand-accent" />
        <div>
          <p className="text-xs text-muted-foreground">대표전화</p>
          <p className="font-semibold text-foreground">{companyContact.phone}</p>
        </div>
      </Link>
      <Link
        href={`mailto:${companyContact.email}`}
        className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/30"
      >
        <Mail className="size-5 text-brand-accent" />
        <div>
          <p className="text-xs text-muted-foreground">이메일</p>
          <p className="font-semibold text-foreground">{companyContact.email}</p>
        </div>
      </Link>
      <Link
        href={siteConfig.contactCta.href}
        className="flex items-center gap-3 rounded-xl border border-primary/20 bg-primary/5 p-4 transition-colors hover:bg-primary/10"
      >
        <ArrowRight className="size-5 text-primary" />
        <div>
          <p className="text-xs text-muted-foreground">빠른 문의</p>
          <p className="font-semibold text-primary">
            {siteConfig.contactCta.label}
          </p>
        </div>
      </Link>
      <Link
        href="/contact/map"
        className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/30"
      >
        <MapPin className="size-5 text-brand-accent" />
        <div>
          <p className="text-xs text-muted-foreground">방문·위치</p>
          <p className="font-semibold text-foreground">오시는 길</p>
        </div>
      </Link>
    </div>
  );
}
