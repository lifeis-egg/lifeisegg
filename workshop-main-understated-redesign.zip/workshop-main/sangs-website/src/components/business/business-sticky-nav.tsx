"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

import { solutionCategoryOrder } from "@/config/home-content";
import {
  getSolutionsByCategory,
  type SolutionItem,
} from "@/lib/solutions";
import { cn } from "@/lib/utils";

const categoryAnchor = (key: SolutionItem["category"]) => `category-${key}`;

export function BusinessStickyNav() {
  const [activeId, setActiveId] = useState<string>("");

  useEffect(() => {
    const ids = [
      ...solutionCategoryOrder.map((c) => categoryAnchor(c.key)),
      ...solutionCategoryOrder.flatMap((c) =>
        getSolutionsByCategory(c.key).map((s) => s.id)
      ),
    ];

    const elements = ids
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]?.target.id) {
          setActiveId(visible[0].target.id);
        }
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.25, 0.5] }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <nav
      className="sticky top-20 hidden max-h-[calc(100vh-6rem)] overflow-y-auto lg:block"
      aria-label="사업분야 목차"
    >
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        목차
      </p>
      <ul className="mt-4 space-y-6 border-l border-border pl-4">
        {solutionCategoryOrder.map(({ key, title }) => {
          const anchor = categoryAnchor(key);
          const items = getSolutionsByCategory(key);
          return (
            <li key={key}>
              <Link
                href={`#${anchor}`}
                className={cn(
                  "text-sm font-semibold transition-colors hover:text-primary",
                  activeId === anchor
                    ? "text-primary"
                    : "text-foreground"
                )}
              >
                {title}
              </Link>
              <ul className="mt-2 space-y-1.5">
                {items.map((item) => (
                  <li key={item.id}>
                    <Link
                      href={`#${item.id}`}
                      className={cn(
                        "block text-xs transition-colors hover:text-primary",
                        activeId === item.id
                          ? "font-medium text-primary"
                          : "text-muted-foreground"
                      )}
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function BusinessMobileNav() {
  return (
    <div className="sticky top-16 z-40 -mx-4 border-b border-border/80 bg-background/95 px-4 py-3 backdrop-blur-md lg:hidden">
      <div className="flex gap-2 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {solutionCategoryOrder.map(({ key, title }) => (
          <Link
            key={key}
            href={`#${categoryAnchor(key)}`}
            className="shrink-0 rounded-full border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-foreground"
          >
            {title}
          </Link>
        ))}
      </div>
    </div>
  );
}
