import Link from "next/link";
import { ArrowRight, Award } from "lucide-react";

import { businessCertifications } from "@/config/home-content";
import { siteConfig } from "@/config/site";
import { Button } from "@/components/ui/button";

export function BusinessCertifications() {
  return (
    <section
      className="rounded-2xl border border-border/80 bg-muted/30 p-8 sm:p-10"
      aria-labelledby="cert-heading"
    >
      <div className="flex items-start gap-3">
        <Award className="mt-0.5 size-5 text-brand-accent" aria-hidden />
        <div>
          <h2
            id="cert-heading"
            className="text-xl font-bold tracking-tight text-foreground"
          >
            인증 · 역량
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            GS인증 LMS·데이터 솔루션과 이러닝·벤처·Inno-Biz 등 공인 역량을
            보유하고 있습니다.
          </p>
        </div>
      </div>
      <ul className="mt-6 grid gap-3 sm:grid-cols-2">
        {businessCertifications.map((item) => (
          <li
            key={item}
            className="rounded-lg border border-border/70 bg-card px-4 py-3 text-sm text-foreground/90"
          >
            {item}
          </li>
        ))}
      </ul>
    </section>
  );
}

export function BusinessCtaBand() {
  return (
    <section className="relative overflow-hidden rounded-2xl bg-primary px-8 py-10 text-primary-foreground sm:px-12 sm:py-14">
      <div
        className="pointer-events-none absolute -right-20 -top-20 size-64 rounded-full bg-white/10 blur-3xl"
        aria-hidden
      />
      <div className="relative max-w-2xl">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
          프로젝트·도입 상담이 필요하신가요?
        </h2>
        <p className="mt-3 text-sm leading-relaxed opacity-90 sm:text-base">
          솔루션 선택, 구축 범위, SM까지 전문 컨설턴트가 맞춤 제안을
          드립니다.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button
            nativeButton={false}
            render={<Link href={siteConfig.contactCta.href} />}
            variant="secondary"
            size="lg"
            className="h-11 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
          >
            {siteConfig.contactCta.label}
            <ArrowRight className="size-4" data-icon="inline-end" />
          </Button>
          <Button
            nativeButton={false}
            render={<Link href="/portfolio" />}
            variant="outline"
            size="lg"
            className="h-11 border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10"
          >
            사업실적 보기
          </Button>
        </div>
      </div>
    </section>
  );
}
