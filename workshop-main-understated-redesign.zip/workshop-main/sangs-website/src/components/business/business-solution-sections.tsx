import { CheckCircle2, Package } from "lucide-react";

import { businessCategoryIntros } from "@/config/home-content";
import {
  categoryIcons,
  getSolutionsByCategory,
  solutionCategoryOrder,
  type SolutionItem,
} from "@/lib/solutions";
import { cn } from "@/lib/utils";

function SolutionDetailCard({
  solution,
  reversed,
}: {
  solution: SolutionItem;
  reversed?: boolean;
}) {
  const Icon = categoryIcons[solution.category];

  return (
    <article
      id={solution.id}
      className="scroll-mt-28 rounded-2xl border border-border/80 bg-card shadow-sm"
    >
      <div
        className={cn(
          "grid gap-0 lg:grid-cols-2",
          reversed && "lg:[&>*:first-child]:order-2"
        )}
      >
        <div className="relative overflow-hidden rounded-t-2xl bg-gradient-to-br from-primary/95 via-primary to-brand-accent/80 p-8 text-primary-foreground lg:rounded-none lg:rounded-l-2xl lg:rounded-tr-none">
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.07)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.07)_1px,transparent_1px)] bg-[size:20px_20px]" />
          <div className="relative">
            <div className="flex items-center gap-3">
              <div className="flex size-12 items-center justify-center rounded-xl bg-white/15">
                <Icon className="size-6" aria-hidden />
              </div>
              {solution.badge ? (
                <span className="rounded-full bg-white/15 px-2.5 py-0.5 text-[11px] font-semibold">
                  {solution.badge}
                </span>
              ) : null}
            </div>
            <p className="mt-6 text-xs font-medium uppercase tracking-widest opacity-80">
              {solution.categoryLabel}
            </p>
            <h3 className="mt-1 text-2xl font-bold tracking-tight">
              {solution.name}
            </h3>
            <p className="mt-4 text-sm leading-relaxed opacity-90">
              {solution.description}
            </p>
          </div>
        </div>

        <div className="p-8 lg:rounded-r-2xl">
          <h4 className="text-sm font-semibold text-foreground">개요</h4>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            {solution.overview}
          </p>

          <h4 className="mt-6 flex items-center gap-2 text-sm font-semibold text-foreground">
            <CheckCircle2 className="size-4 text-brand-accent" aria-hidden />
            주요 기능
          </h4>
          <ul className="mt-3 space-y-2">
            {solution.capabilities.map((cap) => (
              <li
                key={cap}
                className="flex gap-2 text-sm text-foreground/85"
              >
                <span
                  className="mt-2 size-1 shrink-0 rounded-full bg-brand-accent"
                  aria-hidden
                />
                {cap}
              </li>
            ))}
          </ul>

          <h4 className="mt-6 flex items-center gap-2 text-sm font-semibold text-foreground">
            <Package className="size-4 text-brand-accent" aria-hidden />
            제공 범위
          </h4>
          <ul className="mt-3 flex flex-wrap gap-2">
            {solution.deliverables.map((item) => (
              <li
                key={item}
                className="rounded-md border border-border bg-muted/40 px-2.5 py-1 text-xs font-medium text-muted-foreground"
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </article>
  );
}

export function BusinessSolutionSections() {
  return (
    <div className="space-y-20">
      {solutionCategoryOrder.map(({ key }) => {
        const intro = businessCategoryIntros[key];
        const items = getSolutionsByCategory(key);

        return (
          <section
            key={key}
            id={`category-${key}`}
            className="scroll-mt-28"
            aria-labelledby={`heading-${key}`}
          >
            <div className="max-w-3xl">
              <p className="text-xs font-semibold uppercase tracking-widest text-brand-accent">
                {intro.title}
              </p>
              <h2
                id={`heading-${key}`}
                className="mt-2 text-2xl font-bold tracking-tight text-foreground sm:text-3xl"
              >
                {intro.title}
              </h2>
              <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
                {intro.lead}
              </p>
            </div>

            <div className="mt-10 space-y-8">
              {items.map((solution, index) => (
                <SolutionDetailCard
                  key={solution.id}
                  solution={solution}
                  reversed={index % 2 === 1}
                />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
