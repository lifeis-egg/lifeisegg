import Link from "next/link";
import { ChevronRight } from "lucide-react";

import { siteConfig } from "@/config/site";

export function BusinessHero() {
  return (
    <section className="relative overflow-hidden border-b border-border/60 bg-muted/20">
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_70%_50%_at_30%_-10%,var(--brand-glow),transparent)]"
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8 lg:py-20">
        <nav
          className="mb-6 flex items-center gap-1 text-sm text-muted-foreground"
          aria-label="breadcrumb"
        >
          <Link href="/" className="transition-colors hover:text-foreground">
            홈
          </Link>
          <ChevronRight className="size-4 opacity-60" aria-hidden />
          <span className="font-medium text-foreground">사업분야</span>
        </nav>
        <p className="text-xs font-semibold uppercase tracking-widest text-brand-accent">
          Business
        </p>
        <h1 className="mt-2 max-w-3xl font-heading text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          EduTech · Data · SI/SM · AI
          <span className="block text-primary">통합 디지털 전환 스택</span>
        </h1>
        <p className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
          {siteConfig.shortName}는 LMS·데이터 플랫폼·포털 SI·AI 엔진을 아우르는
          솔루션과 구축 역량으로 공공·금융·교육 고객의 과제를 End-to-End로
          지원합니다.
        </p>
      </div>
    </section>
  );
}
