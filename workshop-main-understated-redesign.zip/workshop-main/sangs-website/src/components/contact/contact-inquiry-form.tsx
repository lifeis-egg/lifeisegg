"use client";

import { useState } from "react";
import Link from "next/link";
import { Building2, Clock, Mail, MapPin, Phone } from "lucide-react";

import {
  brochureOptions,
  companyContact,
  companyOffices,
  inquiryTopics,
} from "@/config/contact";
import { siteConfig } from "@/config/site";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

type FormState = {
  company: string;
  name: string;
  email: string;
  phone: string;
  topic: string;
  message: string;
  brochures: string[];
  privacy: boolean;
};

const initialForm: FormState = {
  company: "",
  name: "",
  email: "",
  phone: "",
  topic: "",
  message: "",
  brochures: [],
  privacy: false,
};

export function ContactInquiryForm() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>(
    {}
  );
  const [submitted, setSubmitted] = useState(false);
  const [pending, setPending] = useState(false);

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const toggleBrochure = (value: string) => {
    setForm((prev) => ({
      ...prev,
      brochures: prev.brochures.includes(value)
        ? prev.brochures.filter((v) => v !== value)
        : [...prev.brochures, value],
    }));
  };

  const validate = () => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (!form.company.trim()) next.company = "회사·기관명을 입력해 주세요.";
    if (!form.name.trim()) next.name = "담당자명을 입력해 주세요.";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      next.email = "올바른 이메일을 입력해 주세요.";
    }
    if (!form.topic) next.topic = "문의 유형을 선택해 주세요.";
    if (!form.message.trim()) next.message = "문의 내용을 입력해 주세요.";
    if (!form.privacy) next.privacy = "개인정보 수집·이용에 동의해 주세요.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setPending(true);
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("failed");
      setSubmitted(true);
    } catch {
      setErrors({ message: "전송에 실패했습니다. 잠시 후 다시 시도해 주세요." });
    } finally {
      setPending(false);
    }
  };

  if (submitted) {
    return (
      <div
        className="rounded-2xl border border-border bg-card p-8 text-center shadow-sm sm:p-10"
        role="status"
      >
        <p className="text-lg font-semibold text-foreground">
          문의가 접수되었습니다
        </p>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {siteConfig.shortName} 영업팀에서 영업일 기준 1~2일 내 연락드리겠습니다.
          <br />
          긴급 문의는 대표전화{" "}
          <a
            href={companyContact.phoneHref}
            className="font-medium text-primary hover:underline"
          >
            {companyContact.phone}
          </a>
          로 연락 주세요.
        </p>
        <Button
          type="button"
          variant="outline"
          className="mt-6"
          onClick={() => {
            setSubmitted(false);
            setForm(initialForm);
          }}
        >
          추가 문의하기
        </Button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm sm:p-8"
      noValidate
    >
      <h2 className="text-xl font-bold tracking-tight text-foreground">
        도입·상담 문의
      </h2>
      <p className="mt-2 text-sm text-muted-foreground">
        프로젝트 범위, 일정, 예산감을 알려주시면 맞춤 제안을 드립니다.
      </p>

      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="company">회사·기관명 *</Label>
          <Input
            id="company"
            value={form.company}
            onChange={(e) => update("company", e.target.value)}
            placeholder="(주)○○○ / ○○공공기관"
            aria-invalid={!!errors.company}
          />
          {errors.company ? (
            <p className="text-xs text-destructive">{errors.company}</p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="name">담당자명 *</Label>
          <Input
            id="name"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            aria-invalid={!!errors.name}
          />
          {errors.name ? (
            <p className="text-xs text-destructive">{errors.name}</p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">연락처</Label>
          <Input
            id="phone"
            type="tel"
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="010-0000-0000"
          />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="email">이메일 *</Label>
          <Input
            id="email"
            type="email"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            aria-invalid={!!errors.email}
          />
          {errors.email ? (
            <p className="text-xs text-destructive">{errors.email}</p>
          ) : null}
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="topic">문의 유형 *</Label>
          <Select
            value={form.topic || null}
            onValueChange={(value) => update("topic", value ?? "")}
          >
            <SelectTrigger id="topic" className="h-10 w-full">
              <SelectValue placeholder="솔루션·서비스 선택" />
            </SelectTrigger>
            <SelectContent>
              {inquiryTopics.map((item) => (
                <SelectItem key={item.value} value={item.value}>
                  {item.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.topic ? (
            <p className="text-xs text-destructive">{errors.topic}</p>
          ) : null}
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="message">문의 내용 *</Label>
          <Textarea
            id="message"
            value={form.message}
            onChange={(e) => update("message", e.target.value)}
            placeholder="도입 배경, 희망 일정, 사용자 규모 등"
            className="min-h-32"
            aria-invalid={!!errors.message}
          />
          {errors.message ? (
            <p className="text-xs text-destructive">{errors.message}</p>
          ) : null}
        </div>
      </div>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-foreground">
          브로슈어 수신 (선택)
        </legend>
        <div className="mt-3 flex flex-wrap gap-3">
          {brochureOptions.map((opt) => (
            <label
              key={opt.value}
              className="flex cursor-pointer items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm has-checked:border-primary has-checked:bg-primary/5"
            >
              <input
                type="checkbox"
                className="size-4 rounded border-input accent-primary"
                checked={form.brochures.includes(opt.value)}
                onChange={() => toggleBrochure(opt.value)}
              />
              {opt.label}
            </label>
          ))}
        </div>
      </fieldset>

      <label className="mt-6 flex cursor-pointer items-start gap-3 text-sm">
        <input
          type="checkbox"
          className="mt-0.5 size-4 rounded border-input accent-primary"
          checked={form.privacy}
          onChange={(e) => update("privacy", e.target.checked)}
        />
        <span className="text-muted-foreground">
          <span className="text-foreground">[필수]</span> 개인정보 수집·이용에
          동의합니다. 수집 항목: 회사명, 성명, 연락처, 이메일, 문의내용 — 목적:
          견적·상담 및 브로슈어 제공.
        </span>
      </label>
      {errors.privacy ? (
        <p className="mt-1 text-xs text-destructive">{errors.privacy}</p>
      ) : null}

      <Button type="submit" size="lg" className="mt-8 h-11 w-full sm:w-auto" disabled={pending}>
        {pending ? "전송 중…" : "문의 보내기"}
      </Button>
    </form>
  );
}

export function ContactInfoPanel() {
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border/80 bg-muted/30 p-6">
        <h2 className="text-lg font-bold text-foreground">연락처</h2>
        <ul className="mt-5 space-y-4 text-sm">
          <li className="flex gap-3">
            <Phone className="mt-0.5 size-4 shrink-0 text-brand-accent" />
            <div>
              <p className="font-medium text-foreground">대표전화</p>
              <a
                href={companyContact.phoneHref}
                className="text-primary hover:underline"
              >
                {companyContact.phone}
              </a>
            </div>
          </li>
          <li className="flex gap-3">
            <Mail className="mt-0.5 size-4 shrink-0 text-brand-accent" />
            <div>
              <p className="font-medium text-foreground">이메일</p>
              <a
                href={`mailto:${companyContact.email}`}
                className="text-primary hover:underline"
              >
                {companyContact.email}
              </a>
            </div>
          </li>
          <li className="flex gap-3">
            <Clock className="mt-0.5 size-4 shrink-0 text-brand-accent" />
            <div>
              <p className="font-medium text-foreground">상담 시간</p>
              <p className="text-muted-foreground">{companyContact.businessHours}</p>
            </div>
          </li>
        </ul>
        <Link
          href="/contact/map"
          className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
        >
          <MapPin className="size-4" />
          오시는 길 보기
        </Link>
      </div>

      {companyOffices.map((office) => (
        <div
          key={office.id}
          className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm"
        >
          <div className="flex items-start gap-3">
            <Building2 className="size-4 shrink-0 text-brand-accent" />
            <div>
              <h3 className="font-semibold text-foreground">{office.label}</h3>
              {office.zip ? (
                <p className="mt-1 text-xs text-muted-foreground">
                  우) {office.zip}
                </p>
              ) : null}
              <p className="mt-2 flex gap-2 text-sm leading-relaxed text-muted-foreground">
                <MapPin className="mt-0.5 size-4 shrink-0 opacity-70" aria-hidden />
                {office.address}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
