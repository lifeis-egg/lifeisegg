"use client";

import Link from "next/link";
import { ExternalLink, MapPin, Navigation } from "lucide-react";
import { useState } from "react";

import { companyContact, companyOffices } from "@/config/contact";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  getGoogleMapEmbedUrl,
  getMapDirectionsLinks,
} from "@/lib/map-links";

export function LocationMapSection() {
  const [activeId, setActiveId] =
    useState<(typeof companyOffices)[number]["id"]>("seoul");

  const active =
    companyOffices.find((o) => o.id === activeId) ?? companyOffices[0];
  const links = getMapDirectionsLinks(active.address);
  const embedUrl = getGoogleMapEmbedUrl(active.address);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap gap-2">
        {companyOffices.map((office) => (
          <button
            key={office.id}
            type="button"
            onClick={() => setActiveId(office.id)}
            className={cn(
              "rounded-full border px-4 py-2 text-sm font-semibold transition-colors",
              activeId === office.id
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-muted/50 text-muted-foreground hover:text-foreground"
            )}
          >
            {office.label}
          </button>
        ))}
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-2xl border border-border/80 bg-muted/20 shadow-sm">
          <iframe
            title={`${active.label} 지도`}
            src={embedUrl}
            className="aspect-[4/3] w-full min-h-[280px] border-0 lg:aspect-auto lg:min-h-[360px]"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
          />
          <p className="border-t border-border/60 px-4 py-2 text-[11px] text-muted-foreground">
            지도는 Google Maps 임베드입니다. 정확한 위치는 아래 길찾기 링크를
            이용해 주세요.
          </p>
        </div>

        <div className="flex flex-col rounded-2xl border border-border/80 bg-card p-6 shadow-sm sm:p-8">
          <div className="flex items-start gap-3">
            <MapPin className="mt-0.5 size-5 shrink-0 text-brand-accent" />
            <div>
              <h2 className="text-xl font-bold text-foreground">
                {active.label}
              </h2>
              {active.zip ? (
                <p className="mt-1 text-xs text-muted-foreground">
                  우) {active.zip}
                </p>
              ) : null}
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {active.address}
              </p>
            </div>
          </div>

          {active.id === "seoul" ? (
            <dl className="mt-6 space-y-3 border-t border-border/60 pt-6 text-sm">
              <div className="flex gap-3">
                <dt className="w-16 shrink-0 font-medium text-foreground">
                  전화
                </dt>
                <dd>
                  <a
                    href={companyContact.phoneHref}
                    className="text-primary hover:underline"
                  >
                    {companyContact.phone}
                  </a>
                </dd>
              </div>
              <div className="flex gap-3">
                <dt className="w-16 shrink-0 font-medium text-foreground">
                  팩스
                </dt>
                <dd className="text-muted-foreground">{companyContact.fax}</dd>
              </div>
            </dl>
          ) : null}

          <div className="mt-auto flex flex-col gap-2 pt-8">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              길찾기
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                nativeButton={false}
                render={
                  <a
                    href={links.kakao}
                    target="_blank"
                    rel="noopener noreferrer"
                  />
                }
                variant="outline"
                size="sm"
              >
                카카오맵
                <ExternalLink className="size-3.5" data-icon="inline-end" />
              </Button>
              <Button
                nativeButton={false}
                render={
                  <a
                    href={links.naver}
                    target="_blank"
                    rel="noopener noreferrer"
                  />
                }
                variant="outline"
                size="sm"
              >
                네이버 지도
                <ExternalLink className="size-3.5" data-icon="inline-end" />
              </Button>
              <Button
                nativeButton={false}
                render={
                  <a
                    href={links.google}
                    target="_blank"
                    rel="noopener noreferrer"
                  />
                }
                variant="outline"
                size="sm"
              >
                Google Maps
                <ExternalLink className="size-3.5" data-icon="inline-end" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-dashed border-border bg-muted/20 p-4 text-sm text-muted-foreground">
        <Navigation className="mb-2 inline size-4 text-brand-accent" />
        지하철·주차 등 상세 안내는 방문 전{" "}
        <a href={companyContact.phoneHref} className="font-medium text-primary">
          {companyContact.phone}
        </a>
        로 문의해 주세요. 도입 상담은{" "}
        <Link href="/contact" className="font-medium text-primary hover:underline">
          고객문의
        </Link>
        페이지를 이용하실 수 있습니다.
      </div>
    </div>
  );
}
