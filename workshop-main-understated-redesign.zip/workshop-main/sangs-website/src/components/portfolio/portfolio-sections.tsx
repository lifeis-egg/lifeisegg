"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { useMemo, useState } from "react";

import {
  REFERENCE_PAGE_SIZE,
  referenceCategoryLabels,
  referenceFilters,
  references,
  type ReferenceCategory,
  type ReferenceFilterKey,
  type ReferenceItem,
} from "@/config/references-content";
import { portfolioStats } from "@/config/portfolio-content";
import { siteConfig } from "@/config/site";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const categoryBadge: Record<ReferenceCategory, string> = {
  lms: "bg-violet-100 text-violet-900 dark:bg-violet-950 dark:text-violet-100",
  data: "bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-100",
  sism: "bg-slate-200 text-slate-900 dark:bg-slate-800 dark:text-slate-100",
  con: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-100",
};

function ReferenceCard({ item }: { item: ReferenceItem }) {
  const titleLines = item.title.split("\n").map((line) => line.trim()).filter(Boolean);

  return (
    <article className="overflow-hidden rounded-2xl border border-border/80 bg-card shadow-sm transition-shadow hover:shadow-md">
      <div className="grid lg:grid-cols-[minmax(0,340px)_1fr]">
        <div className="relative aspect-[4/3] bg-muted/40 lg:aspect-auto lg:min-h-[220px]">
          <Image
            src={item.imagePc}
            alt=""
            fill
            className="object-cover object-left-top"
            sizes="(max-width: 1024px) 100vw, 340px"
          />
        </div>
        <div className="flex flex-col p-6 sm:p-8">
          <span
            className={cn(
              "w-fit rounded-full px-2.5 py-0.5 text-[11px] font-semibold",
              categoryBadge[item.category]
            )}
          >
            {referenceCategoryLabels[item.category]}
          </span>
          <h3 className="mt-4 text-lg font-bold leading-snug tracking-tight text-foreground sm:text-xl">
            {titleLines.map((line, i) => (
              <span key={i} className={i > 0 ? "mt-1 block" : undefined}>
                {line}
              </span>
            ))}
          </h3>
          {item.bullets.length > 0 ? (
            <ul className="mt-4 space-y-2 text-sm leading-relaxed text-muted-foreground">
              {item.bullets.map((bullet) => (
                <li key={bullet} className="flex gap-2">
                  <span
                    className="mt-2 size-1 shrink-0 rounded-full bg-brand-accent"
                    aria-hidden
                  />
                  {bullet}
                </li>
              ))}
            </ul>
          ) : null}
          {item.tags ? (
            <p className="mt-4 text-xs font-medium text-brand-accent/90">
              {item.tags}
            </p>
          ) : null}
        </div>
      </div>
    </article>
  );
}

export function PortfolioReferenceList() {
  const [filter, setFilter] = useState<ReferenceFilterKey>("all");
  const [visibleCount, setVisibleCount] = useState(REFERENCE_PAGE_SIZE);

  const filtered = useMemo(() => {
    if (filter === "all") return references;
    return references.filter((r) => r.category === filter);
  }, [filter]);

  const visible = filtered.slice(0, visibleCount);
  const hasMore = visibleCount < filtered.length;

  return (
    <div>
      <ul className="flex flex-wrap gap-2 border-b border-border/60 pb-6">
        {referenceFilters.map((item) => (
          <li key={item.key}>
            <button
              type="button"
              onClick={() => {
                setFilter(item.key);
                setVisibleCount(REFERENCE_PAGE_SIZE);
              }}
              className={cn(
                "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
                filter === item.key
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/60 text-muted-foreground hover:text-foreground"
              )}
            >
              {item.label}
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-10 space-y-8">
        {visible.map((item) => (
          <ReferenceCard key={item.id} item={item} />
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="mt-10 text-center text-sm text-muted-foreground">
          해당 분야 레퍼런스가 없습니다.
        </p>
      ) : null}

      {hasMore ? (
        <div className="mt-10 flex justify-center">
          <Button
            type="button"
            variant="outline"
            size="lg"
            className="min-w-[10rem]"
            onClick={() =>
              setVisibleCount((c) => c + REFERENCE_PAGE_SIZE)
            }
          >
            더 보기 +
          </Button>
        </div>
      ) : null}

      <div className="mt-16 rounded-2xl border border-dashed border-border bg-muted/20 p-8 text-center sm:p-10">
        <p className="text-lg font-semibold text-foreground">
          유사 프로젝트를 계획 중이신가요?
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          레퍼런스·견적·PoC 범위까지 {siteConfig.shortName} 전문팀이
          함께합니다.
        </p>
        <Button
          nativeButton={false}
          render={<Link href={siteConfig.contactCta.href} />}
          className="mt-6 h-11"
        >
          {siteConfig.contactCta.label}
          <ArrowRight className="size-4" data-icon="inline-end" />
        </Button>
      </div>
    </div>
  );
}

export function PortfolioStats() {
  const stats = portfolioStats.map((s) =>
    s.label === "LMS·SI 프로젝트"
      ? { ...s, value: `${references.length}+` }
      : s
  );

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-xl border border-border/80 bg-card px-4 py-5 text-center shadow-sm"
        >
          <p className="text-2xl font-bold tracking-tight text-primary sm:text-3xl">
            {stat.value}
          </p>
          <p className="mt-1 text-xs font-medium text-muted-foreground sm:text-sm">
            {stat.label}
          </p>
        </div>
      ))}
    </div>
  );
}
