import Link from "next/link";
import { ArrowRight, Quote } from "lucide-react";

import {
  companyHistory,
  companyProfile,
  companyVision,
  leadershipMessage,
} from "@/config/company-content";
import { businessCertifications } from "@/config/home-content";
import { companyOffices } from "@/config/contact";
import { siteConfig } from "@/config/site";
import { SectionHeading } from "@/components/ui/section-heading";
import { Button } from "@/components/ui/button";

export function CompanyOverviewSection() {
  return (
    <section className="grid gap-10 lg:grid-cols-2 lg:gap-16">
      <div>
        <SectionHeading
          eyebrow="About"
          title="기업 개요"
          description={companyVision.body}
        />
        <dl className="mt-8 grid gap-4 sm:grid-cols-2">
          {[
            ["법인명", companyProfile.legalName],
            ["설립", companyProfile.founded],
            ["대표이사", companyProfile.ceo],
            ["임직원", companyProfile.employees],
            ["업종", companyProfile.industry],
          ].map(([term, value]) => (
            <div
              key={term}
              className="rounded-xl border border-border/80 bg-card px-4 py-3"
            >
              <dt className="text-xs font-medium text-muted-foreground">
                {term}
              </dt>
              <dd className="mt-1 text-sm font-semibold text-foreground">
                {value}
              </dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="rounded-2xl border border-border/80 bg-primary p-8 text-primary-foreground sm:p-10">
        <Quote className="size-8 opacity-80" aria-hidden />
        <p className="mt-6 text-lg font-medium leading-relaxed">
          &ldquo;{leadershipMessage.quote}&rdquo;
        </p>
        <p className="mt-6 text-sm opacity-90">
          {leadershipMessage.role} {leadershipMessage.name}
        </p>
        <p className="mt-2 text-xs leading-relaxed opacity-75">
          {leadershipMessage.bio}
        </p>
      </div>
    </section>
  );
}

export function CompanyPillarsSection() {
  return (
    <section aria-labelledby="pillars-heading">
      <SectionHeading
        eyebrow="Value"
        title={companyVision.headline}
        description="교육·데이터·AI·SI를 연결하는 상상스토리만의 성장 축입니다."
      />
      <ul className="mt-10 grid gap-6 md:grid-cols-3">
        {companyVision.pillars.map((pillar) => (
          <li
            key={pillar.title}
            className="rounded-2xl border border-border/80 bg-muted/20 p-6"
          >
            <h3 className="font-bold text-foreground">{pillar.title}</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {pillar.description}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function CompanyMainBusinessSection() {
  return (
    <section
      className="rounded-2xl border border-border/80 bg-card p-8 sm:p-10"
      aria-labelledby="business-heading"
    >
      <h2 id="business-heading" className="text-xl font-bold text-foreground">
        주요 사업
      </h2>
      <ul className="mt-6 grid gap-3 sm:grid-cols-2">
        {companyProfile.mainBusiness.map((item) => (
          <li
            key={item}
            className="flex items-center gap-2 rounded-lg border border-border/70 bg-muted/30 px-4 py-3 text-sm text-foreground"
          >
            <span
              className="size-1.5 shrink-0 rounded-full bg-brand-accent"
              aria-hidden
            />
            {item}
          </li>
        ))}
      </ul>
      <p className="mt-6 text-xs text-muted-foreground">
        과거 상호: {companyProfile.formerNames.join(" → ")}
      </p>
    </section>
  );
}

export function CompanyHistorySection() {
  return (
    <section aria-labelledby="history-heading">
      <SectionHeading eyebrow="History" title="연혁" />
      <ol className="relative mt-10 space-y-8 border-l border-border pl-8">
        {companyHistory.map((event) => (
          <li key={event.year} className="relative">
            <span
              className="absolute -left-[2.125rem] top-1 flex size-3 rounded-full border-2 border-background bg-brand-accent"
              aria-hidden
            />
            <p className="text-sm font-bold text-primary">{event.year}</p>
            <h3 className="mt-1 font-semibold text-foreground">{event.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {event.description}
            </p>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function CompanyCertificationsSection() {
  return (
    <section aria-labelledby="company-cert-heading">
      <SectionHeading
        eyebrow="Certification"
        title="인증 · 지정"
        description="GS인증 솔루션과 공인 중소·벤처·이러닝 역량을 보유하고 있습니다."
      />
      <ul className="mt-8 grid gap-3 sm:grid-cols-2">
        {businessCertifications.map((item) => (
          <li
            key={item}
            className="rounded-lg border border-border/70 bg-muted/30 px-4 py-3 text-sm"
          >
            {item}
          </li>
        ))}
      </ul>
    </section>
  );
}

export function CompanyLocationsSection() {
  return (
    <section aria-labelledby="locations-heading">
      <SectionHeading eyebrow="Location" title="오시는 길" />
      <ul className="mt-8 grid gap-4 md:grid-cols-3">
        {companyOffices.map((office) => (
          <li
            key={office.id}
            className="rounded-xl border border-border/80 bg-card p-5 shadow-sm"
          >
            <h3 className="font-semibold text-foreground">{office.label}</h3>
            {office.zip ? (
              <p className="mt-1 text-xs text-muted-foreground">
                우) {office.zip}
              </p>
            ) : null}
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {office.address}
            </p>
          </li>
        ))}
      </ul>
      <Button
        nativeButton={false}
        render={<Link href="/contact/map" />}
        variant="outline"
        className="mt-6"
      >
        지도에서 보기
      </Button>
    </section>
  );
}

export function CompanyPageCta() {
  return (
    <section className="rounded-2xl bg-primary px-8 py-10 text-primary-foreground sm:px-12">
      <h2 className="text-2xl font-bold tracking-tight">
        {siteConfig.shortName}와 함께할 준비가 되셨나요?
      </h2>
      <p className="mt-3 max-w-xl text-sm opacity-90 sm:text-base">
        솔루션 소개부터 사업실적, 도입 상담까지 한 번에 확인하실 수 있습니다.
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button
          nativeButton={false}
          render={<Link href="/business" />}
          variant="secondary"
          className="h-11 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
        >
          사업분야 보기
          <ArrowRight className="size-4" data-icon="inline-end" />
        </Button>
        <Button
          nativeButton={false}
          render={<Link href={siteConfig.contactCta.href} />}
          variant="outline"
          className="h-11 border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10"
        >
          {siteConfig.contactCta.label}
        </Button>
      </div>
    </section>
  );
}
