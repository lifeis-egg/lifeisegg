"use client";

import Link from "next/link";
import { motion, useInView } from "framer-motion";
import {
  ArrowUpRight,
} from "lucide-react";
import { useRef } from "react";

import {
  solutionCategoryOrder,
  solutions,
  type SolutionItem,
} from "@/config/home-content";
import { categoryIcons } from "@/lib/solutions";
import { SectionHeading } from "@/components/ui/section-heading";
import { cn } from "@/lib/utils";

function SolutionCard({
  solution,
  index,
  inView,
}: {
  solution: SolutionItem;
  index: number;
  inView: boolean;
}) {
  const Icon = categoryIcons[solution.category];

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.45, delay: 0.05 * (index % 6) }}
      className="site-soft-panel group flex min-h-[295px] flex-col rounded-xl border border-border bg-card p-6 transition-[box-shadow,border-color] hover:border-primary/20"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-5" aria-hidden />
        </div>
        {solution.badge ? (
          <span className="rounded-full bg-brand-accent/10 px-2.5 py-0.5 text-[11px] font-semibold text-brand-accent">
            {solution.badge}
          </span>
        ) : null}
      </div>

      <p className="mt-4 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {solution.categoryLabel}
      </p>
      <h3 className="mt-1 text-lg font-bold tracking-tight text-foreground">
        {solution.name}
      </h3>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
        {solution.description}
      </p>

      <ul className="mt-4 space-y-1.5">
        {solution.highlights.map((item) => (
          <li
            key={item}
            className="flex items-center gap-2 text-xs text-foreground/80"
          >
            <span
              className="size-1 shrink-0 rounded-full bg-brand-accent"
              aria-hidden
            />
            {item}
          </li>
        ))}
      </ul>

      <Link
        href={`/business#${solution.id}`}
        className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-primary transition-colors group-hover:gap-2"
      >
        자세히 보기
        <ArrowUpRight className="size-4" aria-hidden />
      </Link>
    </motion.article>
  );
}

export function SolutionsGridSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });

  return (
    <section
      ref={ref}
      className="py-16 sm:py-24"
      aria-labelledby="solutions-heading"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Solutions"
          title="솔루션 & 데이터 플랫폼"
          description="에듀테크 LMS부터 데이터 수집·품질·메타, SI/SM, AI 엔진까지 — 상상스토리 통합 스택으로 고객 과제를 End-to-End로 지원합니다."
        />

        <div className="mt-9 flex flex-wrap gap-2">
          {solutionCategoryOrder.map(({ key, title }) => (
            <span
              key={key}
              className={cn(
                "rounded-full border border-border bg-muted/50 px-3 py-1 text-xs font-medium text-muted-foreground"
              )}
            >
              {title}
            </span>
          ))}
        </div>

        <div className="mt-9 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {solutions.map((solution, index) => (
            <SolutionCard
              key={solution.id}
              solution={solution}
              index={index}
              inView={inView}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
