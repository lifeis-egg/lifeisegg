"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

import {
  clientReferences,
  projectHighlights,
} from "@/config/home-content";
import { SectionHeading } from "@/components/ui/section-heading";
import { cn } from "@/lib/utils";

const sectorStyles: Record<ClientReference["sector"], string> = {
  공공: "border-sky-200/80 bg-sky-50/80 text-sky-900 dark:border-sky-900/40 dark:bg-sky-950/40 dark:text-sky-100",
  금융:
    "border-emerald-200/80 bg-emerald-50/80 text-emerald-900 dark:border-emerald-900/40 dark:bg-emerald-950/40 dark:text-emerald-100",
  교육:
    "border-violet-200/80 bg-violet-50/80 text-violet-900 dark:border-violet-900/40 dark:bg-violet-950/40 dark:text-violet-100",
  기업:
    "border-border bg-muted/60 text-foreground",
};

type ClientReference = (typeof clientReferences)[number];

function ClientLogoTile({
  client,
  className,
}: {
  client: ClientReference;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex h-16 min-w-[11rem] shrink-0 items-center justify-center rounded-xl border px-5 shadow-sm",
        sectorStyles[client.sector],
        className
      )}
    >
      <span className="text-center text-sm font-semibold tracking-tight">
        {client.name}
      </span>
    </div>
  );
}

export function ClientReferenceSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const marqueeItems = [...clientReferences, ...clientReferences];

  return (
    <section
      ref={ref}
      className="border-b border-border/70 bg-muted/15 py-14 sm:py-[72px]"
      aria-labelledby="clients-heading"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
        >
          <SectionHeading
            eyebrow="Reference"
            title="공공·금융·교육 분야와 함께합니다"
            description="20년 이상 축적한 LMS·데이터·SI/SM 프로젝트 경험으로 국내 주요 기관의 디지털 전환을 지원하고 있습니다."
          />
        </motion.div>

        <div className="relative mt-12 overflow-hidden mask-edge-fade">
          <div className="flex w-max animate-marquee gap-4 pause-on-hover">
            {marqueeItems.map((client, index) => (
              <ClientLogoTile
                key={`${client.name}-${index}`}
                client={client}
              />
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"
        >
          {projectHighlights.map((project) => (
            <article
              key={project.title}
              className="site-soft-panel rounded-lg border border-border bg-card p-5 transition-shadow"
            >
              <p className="text-xs font-medium text-brand-accent">
                {project.client}
              </p>
              <h3 className="mt-2 text-sm font-semibold leading-snug text-foreground">
                {project.title}
              </h3>
            </article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
