"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";

import { siteConfig } from "@/config/site";
import { Button } from "@/components/ui/button";

const fadeUp = {
  hidden: { opacity: 0, y: 18 },
  visible: (delay: number) => ({ opacity: 1, y: 0, transition: { duration: 0.48, delay, ease: [0.22, 1, 0.36, 1] as const } }),
};

export function HeroSection() {
  return (
    <section className="relative overflow-hidden border-b border-border/70">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_70%_55%_at_55%_-15%,var(--brand-glow),transparent)]" aria-hidden />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 sm:py-[4.5rem] lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:gap-14 lg:px-8 lg:py-[5.75rem]">
        <div className="max-w-xl lg:pt-3">
          <motion.div custom={0} initial="hidden" animate="visible" variants={fadeUp} className="mb-5 inline-flex items-center gap-2 border border-border bg-muted/40 px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
            <Sparkles className="size-3 text-brand-accent" aria-hidden />
            EduTech · Data · AI · SI/SM
          </motion.div>
          <motion.h1 custom={0.07} initial="hidden" animate="visible" variants={fadeUp} className="max-w-[610px] text-balance font-heading text-[2.35rem] font-bold leading-[1.2] tracking-[-0.045em] text-foreground sm:text-5xl lg:text-[3.1rem]">
            데이터와 AI로<br /><span className="text-primary">교육·경영의 미래</span>를 설계합니다
          </motion.h1>
          <motion.p custom={0.14} initial="hidden" animate="visible" variants={fadeUp} className="mt-5 max-w-[560px] text-[16px] leading-7 text-muted-foreground sm:text-[17px]">
            {siteConfig.description}. SS-LMS부터 데이터 품질·메타, AI 엔진까지 하나의 파트너로 고객의 디지털 전환을 지원합니다.
          </motion.p>
          <motion.div custom={0.21} initial="hidden" animate="visible" variants={fadeUp} className="mt-8 flex flex-col gap-2.5 sm:flex-row sm:items-center">
            <Button nativeButton={false} render={<Link href={siteConfig.contactCta.href} />} size="lg" className="h-10 rounded-md px-5 text-sm">
              {siteConfig.contactCta.label}<ArrowRight className="size-4" data-icon="inline-end" />
            </Button>
            <Button nativeButton={false} render={<Link href="/business" />} variant="outline" size="lg" className="h-10 rounded-md px-5 text-sm">솔루션 둘러보기</Button>
          </motion.div>
          <p className="mt-7 text-[11px] text-muted-foreground/80">교육과 기업을 위한 디지털 전환 파트너 · Since 2000s</p>
        </div>

        <motion.div initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.65, delay: 0.18 }} className="relative mx-auto w-full max-w-[520px] lg:mt-6">
          <div className="site-soft-panel relative aspect-[1.08/1] overflow-hidden rounded-xl border border-border bg-card">
            <div className="absolute inset-x-0 top-0 h-1 bg-primary/80" />
            <div className="absolute right-[-35px] top-[-35px] size-40 rounded-full border border-brand-accent/15" />
            <div className="relative flex h-full flex-col justify-between p-6 sm:p-7">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">Platform Overview</p>
                <p className="mt-2 text-xl font-semibold tracking-tight text-foreground">통합 디지털 전환 스택</p>
                <p className="mt-2 max-w-sm text-xs leading-5 text-muted-foreground">필요한 영역을 연결하고, 운영 과정에서 생기는 데이터를 다시 활용합니다.</p>
              </div>
              <ul className="grid grid-cols-2 gap-2.5">
                {["SS-LMS", "SS-COLLECTOR", "SS-META", "SS-AI Engine"].map((name, i) => (
                  <li key={name} className={"border bg-muted/30 px-3 py-3 text-sm font-medium " + (i === 2 ? "rounded-md" : "rounded-lg")}>{name}</li>
                ))}
              </ul>
            </div>
          </div>
          <p className="mt-3 pl-1 text-[10px] text-muted-foreground">* 실제 제품 화면은 프로젝트 범위에 따라 달라질 수 있습니다.</p>
        </motion.div>
      </div>
    </section>
  );
}
