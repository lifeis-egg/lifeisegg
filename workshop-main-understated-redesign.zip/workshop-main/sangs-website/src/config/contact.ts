export const companyOffices = [
  {
    id: "seoul",
    label: "서울 본사",
    address: "서울특별시 구로구 디지털로 288 대륭포스트타워1차 2006호",
    zip: "08390",
  },
  {
    id: "sejong",
    label: "세종 개발실",
    address: "세종특별자치시 절재로 194 세종중앙타운 719호",
    zip: "30103",
  },
  {
    id: "us",
    label: "미국 지사",
    address: "1131 E Main St, Tustin CA 92780",
    zip: "",
  },
] as const;

export const companyContact = {
  phone: "02-6677-3082",
  phoneHref: "tel:+82266773082",
  fax: "02-6677-3085",
  email: "contact@sangs.co.kr",
  businessHours: "평일 09:00 – 18:00 (주말·공휴일 휴무)",
} as const;

export const inquiryTopics = [
  { value: "lms", label: "SS-LMS / EduTech" },
  { value: "data", label: "Data (COLLECTOR · META · DQ · ML)" },
  { value: "si", label: "SI / SM · Portal" },
  { value: "ai", label: "SS-AI Engine" },
  { value: "contents", label: "교육 콘텐츠" },
  { value: "other", label: "기타 / 종합 상담" },
] as const;

export const brochureOptions = [
  { value: "company", label: "회사 소개서" },
  { value: "lms", label: "LMS 솔루션 브로슈어" },
  { value: "data", label: "데이터 플랫폼 브로슈어" },
] as const;
