import referencesJson from "./references.json";

export type ReferenceCategory = "lms" | "data" | "sism" | "con";

export type ReferenceItem = {
  id: string;
  category: ReferenceCategory;
  imagePc: string;
  imageMo?: string;
  title: string;
  bullets: string[];
  tags?: string;
};

export const references = referencesJson as ReferenceItem[];

export const referenceFilters = [
  { key: "all" as const, label: "전체" },
  { key: "lms" as const, label: "에듀테크" },
  { key: "data" as const, label: "데이터" },
  { key: "sism" as const, label: "정보화" },
  { key: "con" as const, label: "콘텐츠" },
];

export type ReferenceFilterKey = (typeof referenceFilters)[number]["key"];

export const referenceCategoryLabels: Record<ReferenceCategory, string> = {
  lms: "에듀테크",
  data: "데이터",
  sism: "정보화",
  con: "콘텐츠",
};

export const REFERENCE_PAGE_SIZE = 10;
