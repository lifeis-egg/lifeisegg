export const siteConfig = {
  name: "(주)상상스토리",
  shortName: "상상스토리",
  description:
    "에듀테크 LMS, 데이터 품질·분석, SI/SM, AI 엔진까지 — 교육과 기업의 디지털 전환을 선도하는 B2B IT 파트너",
  url: "https://www.sangs.co.kr",
  contactCta: {
    label: "도입 문의",
    href: "/contact",
  },
} as const;

export type NavItem = {
  title: string;
  href: string;
  description?: string;
};

export const mainNav: NavItem[] = [
  { title: "기업정보", href: "/company" },
  { title: "사업분야", href: "/business" },
  { title: "사업실적", href: "/portfolio" },
  { title: "고객지원", href: "/support" },
];

/** 푸터 — GNB + 오시는 길 · 도입 문의 */
export const footerNav: NavItem[] = [
  ...mainNav,
  { title: "오시는 길", href: "/contact/map" },
  { title: "도입 문의", href: "/contact" },
];
