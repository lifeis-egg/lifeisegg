import type { ClientReference } from "@/config/home-content";

export type CaseStudy = {
  id: string;
  client: string;
  sector: ClientReference["sector"];
  title: string;
  summary: string;
  challenge: string;
  solution: string;
  outcomes: string[];
  tags: string[];
  period?: string;
};

export const portfolioStats = [
  { label: "설립", value: "2005" },
  { label: "LMS·SI 프로젝트", value: "100+" },
  { label: "GS인증 솔루션", value: "2" },
  { label: "전문 인력", value: "60+" },
] as const;

/** 공개 사업실적·레퍼런스 기반 사례 (수치는 예시·개편 시 고객 확인 필요) */
export const caseStudies: CaseStudy[] = [
  {
    id: "krx-derivatives",
    client: "한국거래소",
    sector: "금융",
    title: "파생상품 교육시스템 구축",
    summary:
      "파생상품 전문 교육 과정 운영과 이수 관리를 위한 통합 e-Learning 플랫폼을 구축했습니다.",
    challenge:
      "분산된 교육 자료와 수기 이수 관리로 인해 교육 이력 추적과 compliance 대응에 한계가 있었습니다.",
    solution:
      "SS-LMS 기반 과정·차수·평가 체계를 설계하고, 맞춤형 콘텐츠와 관리자 포털을 연동했습니다.",
    outcomes: [
      "교육 과정·이수 이력의 중앙 집중 관리",
      "온라인 평가·이수증 발급 프로세스 자동화",
      "운영 매뉴얼·SM 체계 정립",
    ],
    tags: ["SS-LMS", "금융교육", "SI"],
    period: "금융",
  },
  {
    id: "mgf-portal",
    client: "서민금융진흥원",
    sector: "공공",
    title: "통합 교육포털시스템 구축",
    summary:
      "서민금융 교육 프로그램을 하나의 포털에서 신청·학습·이력 관리할 수 있도록 통합했습니다.",
    challenge:
      "다양한 교육 채널과 레거시 시스템이 분리되어 사용자 경험과 운영 효율이 떨어졌습니다.",
    solution:
      "SS-Portal·LMS 연계 아키텍처로 통합 교육포털을 구축하고 SSO·권한 체계를 적용했습니다.",
    outcomes: [
      "교육 신청~이수까지 원스톱 UX",
      "관리자 대시보드 기반 운영 효율 개선",
      "확장 가능한 모듈형 포털 구조",
    ],
    tags: ["SS-Portal", "SS-LMS", "공공"],
  },
  {
    id: "koca-chemical",
    client: "화학물질안전원",
    sector: "공공",
    title: "유해화학물질 안전교육 시스템",
    summary:
      "법정 안전교육 이수 요건을 충족하는 온라인 교육·평가·이력 관리 시스템을 제공했습니다.",
    challenge:
      "대상자 규모와 교육 주기에 맞춘 안정적인 수강·평가 운영과 이력 증빙이 필요했습니다.",
    solution:
      "LMS 과정 체계·모바일 학습·자동 알림을 적용하고, 이수 리포트를 표준화했습니다.",
    outcomes: [
      "법정 교육 이수율·이력 가시화",
      "반복 운영 업무 부담 경감",
      "콘텐츠 개정·배포 프로세스 체계화",
    ],
    tags: ["SS-LMS", "안전교육", "콘텐츠"],
  },
  {
    id: "finance-edu",
    client: "한국소비자원 · 한국장학재단",
    sector: "공공",
    title: "금융 교육 프로그램·플랫폼",
    summary:
      "금융 소비자·장학 연계 교육을 위한 프로그램 기획과 LMS·콘텐츠 일괄 개발을 수행했습니다.",
    challenge:
      "대상별 맞춤 커리큘럼과 접근성 높은 학습 UX가 동시에 요구되었습니다.",
    solution:
      "과정 설계·SCORM 콘텐츠·LMS 운영을 패키지로 제공하고, 평가·설문 모듈을 통합했습니다.",
    outcomes: [
      "대상별 학습 경로 구성",
      "멀티 디바이스 학습 지원",
      "운영·개정 SM 연계",
    ],
    tags: ["콘텐츠", "SS-LMS", "금융"],
  },
  {
    id: "mfds-edu",
    client: "식품의약품안전청",
    sector: "공공",
    title: "온라인 교육시스템",
    summary:
      "식약 분야 전문 인력·업체 대상 온라인 교육 인프라를 구축·운영 지원했습니다.",
    challenge:
      "전문 분야별 교육 콘텐츠와 이수 관리를 안정적으로 제공할 플랫폼이 필요했습니다.",
    solution:
      "LMS 커스터마이징과 교육 콘텐츠 제작, 관리자 교육까지 일괄 수행했습니다.",
    outcomes: [
      "분야별 교육 과정 체계화",
      "이수·통계 리포트 표준화",
      "장기 SM 기반 안정 운영",
    ],
    tags: ["SS-LMS", "공공", "콘텐츠"],
  },
  {
    id: "cyber-police",
    client: "경찰청 사이버수사대",
    sector: "공공",
    title: "사이버수사 관련 포털·웹 개편",
    summary:
      "대국민 정보 제공과 업무 연계를 고려한 포털·웹 환경 개선 SI를 수행했습니다.",
    challenge:
      "보안·접근성·확장성을 만족하는 웹 아키텍처와 콘텐츠 구조 재정비가 필요했습니다.",
    solution:
      "요구사항 분석·UI/UX·시스템 구축·테스트를 단계별로 수행하고 운영 이관을 지원했습니다.",
    outcomes: [
      "통합 정보 구조·내비게이션 개선",
      "웹 표준·보안 가이드 준수",
      "SM 대응 체계 수립",
    ],
    tags: ["SI/SM", "SS-Portal"],
  },
  {
    id: "lg-library",
    client: "LG 상남도서관",
    sector: "교육",
    title: "온라인 교육·문화 프로그램",
    summary:
      "도서관 기반 온라인 학습·문화 프로그램을 위한 교육 플랫폼을 구축했습니다.",
    challenge:
      "다양한 연령층을 위한 프로그램 등록·수강·커뮤니티 기능이 필요했습니다.",
    solution:
      "LMS·포털 기능을 결합한 맞춤형 교육 사이트를 설계·구축했습니다.",
    outcomes: [
      "프로그램 등록·수강 프로세스 디지털화",
      "운영자 친화적 관리 화면",
      "콘텐츠 확장 기반 마련",
    ],
    tags: ["SS-LMS", "교육"],
  },
  {
    id: "hrdk",
    client: "한국직업능력개발원",
    sector: "교육",
    title: "이러닝 교육과정·플랫폼",
    summary:
      "직업능력개발 분야 이러닝 우수 사례 경험을 바탕으로 교육과정·시스템을 제공했습니다.",
    challenge:
      "표준 이러닝 품질 기준에 맞는 과정 운영과 학습자 만족도를 동시에 달성해야 했습니다.",
    solution:
      "교육 설계·LMS·운영 프로세스를 패키지로 제공하고, 지속 개선 SM을 연계했습니다.",
    outcomes: [
      "우수 이러닝 과정 운영 노하우 반영",
      "학습·평가 데이터 기반 개선",
      "장기 파트너십 기반 운영",
    ],
    tags: ["EduTech", "SS-LMS"],
  },
];

export const portfolioSectors = [
  { key: "all" as const, label: "전체" },
  { key: "공공" as const, label: "공공" },
  { key: "금융" as const, label: "금융" },
  { key: "교육" as const, label: "교육" },
  { key: "기업" as const, label: "기업" },
];
