import { companyContact } from "@/config/contact";

export type FaqItem = {
  id: string;
  question: string;
  answer: string;
  category: "도입" | "기술" | "운영" | "자료";
};

export const supportFaqs: FaqItem[] = [
  {
    id: "faq-1",
    category: "도입",
    question: "솔루션 도입 상담은 어떻게 진행되나요?",
    answer:
      "홈페이지 도입 문의 또는 대표전화(02-6677-3082)로 접수해 주시면, 영업일 기준 1~2일 내 담당자가 연락드립니다. 요구사항·일정·예산감을 바탕으로 PoC 범위, 구축·라이선스·SM 견적을 제안합니다.",
  },
  {
    id: "faq-2",
    category: "도입",
    question: "GS인증 LMS와 데이터 솔루션의 차이는 무엇인가요?",
    answer:
      "SS-LMS는 교육 과정·수강·평가·AI 학습 지도를 담당하는 EduTech 플랫폼이고, SS-COLLECTOR/META/DQ/ML은 데이터 수집·표준·품질·분석을 담당하는 Data 플랫폼입니다. 필요에 따라 단독 또는 통합 구성이 가능합니다.",
  },
  {
    id: "faq-3",
    category: "기술",
    question: "클라우드·온프레미스 모두 지원하나요?",
    answer:
      "고객 보안·규정에 따라 온프레미스, 폐쇄망, 공공·민간 클라우드 등 환경에 맞춰 아키텍처를 설계합니다. 레거시·SSO·그룹웨어 연계 경험을 보유하고 있습니다.",
  },
  {
    id: "faq-4",
    category: "운영",
    question: "구축 이후 SM(유지보수)는 어떻게 제공되나요?",
    answer:
      "장애 대응, 패치·버전 업그레이드, 기능 개선, 콘텐츠·데이터 운영 지원 등 SLA 기반 SM 계약을 제공합니다. SS-Portal·LMS·데이터 플랫폼별 전담 조직이 대응합니다.",
  },
  {
    id: "faq-5",
    category: "운영",
    question: "교육 콘텐츠만 별도 의뢰할 수 있나요?",
    answer:
      "가능합니다. SCORM 패키징, 과정 설계, 영상·인터랙션 제작 후 SS-LMS 또는 고객사 LMS에 등록까지 지원합니다.",
  },
  {
    id: "faq-6",
    category: "자료",
    question: "회사 소개서·솔루션 브로슈어는 어디서 받을 수 있나요?",
    answer:
      "도입 문의 페이지에서 브로슈어 수신 항목을 선택해 요청하시거나, contact@sangs.co.kr 로 회사명·담당자 정보를 보내 주세요. 검토 후 PDF를 전달드립니다.",
  },
];

export const supportChannels = [
  {
    id: "sales",
    title: "영업 · 도입 문의",
    description: "신규 프로젝트, 견적, PoC, 제휴",
    contact: companyContact.phone,
    href: companyContact.phoneHref,
    action: { label: "온라인 문의", href: "/contact" },
  },
  {
    id: "sm",
    title: "기술 · SM 지원",
    description: "운영 장애, 패치, 기능 문의 (계약 고객)",
    contact: companyContact.email,
    href: `mailto:${companyContact.email}`,
    action: { label: "이메일 보내기", href: `mailto:${companyContact.email}` },
  },
  {
    id: "map",
    title: "오시는 길",
    description: "서울·세종·미국 지사 위치",
    contact: "지도 안내",
    href: undefined,
    action: { label: "오시는 길", href: "/contact/map" },
  },
  {
    id: "fax",
    title: "팩스",
    description: "서류·공문 송부",
    contact: companyContact.fax,
    href: undefined,
    action: { label: "도입 문의", href: "/contact" },
  },
] as const;

export type DownloadResource = {
  id: string;
  title: string;
  description: string;
  format: string;
};

export const downloadResources: DownloadResource[] = [
  {
    id: "company",
    title: "회사 소개서",
    description: "기업 개요, 조직, 인증, 주요 레퍼런스 요약",
    format: "PDF",
  },
  {
    id: "lms",
    title: "SS-LMS 브로슈어",
    description: "AI-LMS 기능, GS인증, 도입 프로세스",
    format: "PDF",
  },
  {
    id: "data",
    title: "데이터 플랫폼 브로슈어",
    description: "COLLECTOR · META · DQ · ML 개요",
    format: "PDF",
  },
];

export const supportProcess = [
  { step: "01", title: "접수", detail: "전화·이메일·온라인 문의" },
  { step: "02", title: "상담", detail: "요구사항·범위·일정 확인" },
  { step: "03", title: "제안", detail: "견적·아키텍처·레퍼런스 공유" },
  { step: "04", title: "수행", detail: "구축·교육·오픈·SM" },
] as const;
