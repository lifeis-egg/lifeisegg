export type ClientReference = {
  name: string;
  sector: "공공" | "금융" | "교육" | "기업";
};

/** 공식 홈페이지·사업실적 기반 레퍼런스 (로고는 추후 이미지로 교체) */
export const clientReferences: ClientReference[] = [
  { name: "한국거래소", sector: "금융" },
  { name: "한국장학재단", sector: "공공" },
  { name: "서민금융진흥원", sector: "공공" },
  { name: "한국소비자원", sector: "공공" },
  { name: "식품의약품안전청", sector: "공공" },
  { name: "화학물질안전원", sector: "공공" },
  { name: "경찰청 사이버수사대", sector: "공공" },
  { name: "한국직업능력개발원", sector: "교육" },
  { name: "LG 상남도서관", sector: "교육" },
];

export type ProjectHighlight = {
  client: string;
  title: string;
};

export const projectHighlights: ProjectHighlight[] = [
  {
    client: "한국거래소",
    title: "파생상품 교육시스템 구축",
  },
  {
    client: "서민금융진흥원",
    title: "통합 교육포털시스템 구축",
  },
  {
    client: "화학물질안전원",
    title: "유해화학물질 안전교육 시스템",
  },
  {
    client: "한국소비자원 · 한국장학재단",
    title: "금융 교육 프로그램·플랫폼 개발",
  },
];

export type SolutionItem = {
  id: string;
  name: string;
  category: "edutech" | "data" | "si" | "ai";
  categoryLabel: string;
  description: string;
  highlights: string[];
  badge?: string;
  overview: string;
  capabilities: string[];
  deliverables: string[];
};

/** [sangs.co.kr](https://www.sangs.co.kr/) 메인 사업 영역 정리 */
export const solutions: SolutionItem[] = [
  {
    id: "ss-lms",
    name: "SS-LMS",
    category: "edutech",
    categoryLabel: "EduTech",
    description:
      "AI 기반 학습관리·교육운영을 하나의 플랫폼에서. GS인증 LMS v2.0으로 검증된 에듀테크 코어.",
    highlights: ["과정·수강·평가 통합", "AI 학습 지도", "콘텐츠 연계"],
    badge: "GS인증",
    overview:
      "교육기관·공공·기업의 blended/온라인 교육 운영을 위한 핵심 LMS입니다. 과정 개설부터 수강·평가·이수까지 전 과정을 웹 기반으로 통합하고, AI 학습 지도 특허 기술로 학습 성과를 높입니다.",
    capabilities: [
      "과정·차수·수강생·강사 통합 관리",
      "시험·과제·설문·이수증 발급",
      "모바일·웹 멀티 채널 학습",
      "AI 기반 학습 경로·피드백",
      "타 시스템(HR, 그룹웨어) 연계",
    ],
    deliverables: [
      "LMS 구축·커스터마이징",
      "운영 매뉴얼·관리자 교육",
      "SM· 기능 고도화",
    ],
  },
  {
    id: "contents",
    name: "교육 콘텐츠",
    category: "edutech",
    categoryLabel: "EduTech",
    description:
      "다양한 교육 유형에 맞춘 디지털 콘텐츠 제작·운영으로 학습 경험을 완성합니다.",
    highlights: ["맞춤형 과정 설계", "멀티 디바이스", "운영·유지보수"],
    overview:
      "직무·자격·법정·금융 등 목적별 e-Learning 콘텐츠를 기획·제작·개편합니다. SCORM 등 표준 규격과 LMS 연동을 전제로 학습 설계부터 멀티미디어 제작까지 일괄 제공합니다.",
    capabilities: [
      "교육과정·스토리보드 설계",
      "동영상·인터랙션 콘텐츠 제작",
      "SCORM 패키징·LMS 등록",
      "접근성·모바일 최적화",
      "콘텐츠 개정·버전 관리",
    ],
    deliverables: ["콘텐츠 제작", "런칭·QA", "운영·개정 SM"],
  },
  {
    id: "ss-collector",
    name: "SS-COLLECTOR",
    category: "data",
    categoryLabel: "Data",
    description:
      "방대한 데이터의 수집·저장·연계를 자동화하는 데이터 수집·관리 솔루션.",
    highlights: ["다원 데이터 수집", "스케줄·이력 관리", "플랫폼 연동"],
    overview:
      "DB·파일·API·레거시 등 이기종 소스에서 데이터를 안정적으로 수집·적재합니다. 스케줄·재처리·이력 추적으로 대용량 데이터 파이프라인의 시작점을 담당합니다.",
    capabilities: [
      "배치·실시간 수집 어댑터",
      "수집 스케줄·모니터링",
      "적재·Staging·이력 관리",
      "오류 알림·재처리",
      "데이터 lake/warehouse 연계",
    ],
    deliverables: ["수집 아키텍처 설계", "COLLECTOR 구축", "운영 가이드"],
  },
  {
    id: "ss-meta",
    name: "SS-META",
    category: "data",
    categoryLabel: "Data",
    description:
      "표준 메타데이터 체계로 데이터 자산을 일관되게 정의·관리합니다.",
    highlights: ["표준화·코드 관리", "데이터 카탈로그", "거버넌스"],
    overview:
      "데이터 표준·메타데이터·코드 체계를 중앙에서 정의·배포·변경 관리합니다. 분석·품질·BI 프로젝트의 공통 언어를 제공해 데이터 거버넌스 기반을 만듭니다.",
    capabilities: [
      "표준 용어·도메인·코드 관리",
      "테이블·컬럼 메타 등록",
      "표준 준수 검증·리포트",
      "데이터 카탈로그 연동",
      "변경 이력·승인 워크플로",
    ],
    deliverables: ["메타 표준 수립", "SS-META 구축", "거버넌스 프로세스 정립"],
  },
  {
    id: "ss-dq",
    name: "SS-DQ",
    category: "data",
    categoryLabel: "Data",
    description:
      "데이터 품질 진단·모니터링으로 신뢰 가능한 분석 기반을 만듭니다.",
    highlights: ["품질 규칙·진단", "이상 탐지", "품질 리포트"],
    overview:
      "정합성·완전성·적시성 등 품질 지표를 규칙으로 정의하고 주기적으로 진단합니다. 품질 이슈를 조기에 발견해 분석·AI 모델의 신뢰도를 높입니다.",
    capabilities: [
      "품질 규칙·프로파일링",
      "자동 진단·스코어링",
      "품질 대시보드·리포트",
      "이슈 추적·조치 이력",
      "META·COLLECTOR 연계",
    ],
    deliverables: ["품질 기준 정의", "SS-DQ 구축", "품질 운영 체계"],
  },
  {
    id: "ss-ml",
    name: "SS-ML",
    category: "data",
    categoryLabel: "Data",
    description:
      "분석·성능 관리에 특화된 머신러닝 워크로드를 지원합니다.",
    highlights: ["분석 파이프라인", "성능 모니터링", "예측·분류"],
    overview:
      "분석 모델 학습·배포·성능 추적을 지원하는 ML 워크로드 레이어입니다. 교육·경영 데이터에 특화된 분석 시나리오와 연계해 인사이트 도출을 가속합니다.",
    capabilities: [
      "학습·추론 파이프라인",
      "모델 버전·성능 모니터링",
      "예측·분류·클러스터링",
      "Feature Store 연계",
      "AI Engine·BI 연동",
    ],
    deliverables: ["ML use case 정의", "파이프라인 구축", "모델 운영"],
  },
  {
    id: "ss-portal",
    name: "SS-Portal",
    category: "si",
    categoryLabel: "SI / SM",
    description:
      "풍부한 SI/SM 노하우로 포털·업무시스템을 체계적으로 구축·운영합니다.",
    highlights: ["통합 포털", "레거시 연계", "운영·SM"],
    overview:
      "교육·업무·민원 등 통합 포털과 맞춤형 업무 시스템을 요구사항 분석부터 구축·테스트·오픈·SM까지 수행합니다. 공공·금융 도메인 SI 경험을 바탕으로 안정적인 운영을 지원합니다.",
    capabilities: [
      "통합 포털·SSO·권한",
      "업무 프로세스 시스템화",
      "레거시·외부 API 연계",
      "웹 접근성·보안 준수",
      "SM· 장애·성능 관리",
    ],
    deliverables: ["요구사항·설계", "구축·통합 테스트", "SM· 고도화"],
  },
  {
    id: "ss-ai",
    name: "SS-AI Engine",
    category: "ai",
    categoryLabel: "AI",
    description:
      "교육과정 추천·경영데이터 분석 등 AI 엔진 기반 의사결정을 지원합니다.",
    highlights: ["과정 추천", "경영 데이터 분석", "ML 파이프라인"],
    badge: "AI Engine",
    overview:
      "교육과정 추천, 학습 패턴 분석, 경영·KPI 데이터 분석 등 AI 기반 의사결정 시나리오에 특화된 엔진입니다. LMS·데이터 플랫폼과 결합해 추천·예측 서비스를 구현합니다.",
    capabilities: [
      "개인화 과정·콘텐츠 추천",
      "학습 이탈·성과 예측",
      "경영 KPI·트렌드 분석",
      "NLP·분류 모델 연계",
      "API 기반 AI 서비스 제공",
    ],
    deliverables: ["AI use case 설계", "엔진·모델 통합", "PoC→운영 전환"],
  },
];

export const solutionCategoryOrder = [
  { key: "edutech" as const, title: "EduTech · LMS" },
  { key: "data" as const, title: "Data Platform" },
  { key: "si" as const, title: "SI / SM" },
  { key: "ai" as const, title: "AI Engine" },
];

export const businessCategoryIntros: Record<
  (typeof solutionCategoryOrder)[number]["key"],
  { title: string; lead: string }
> = {
  edutech: {
    title: "EduTech · LMS",
    lead: "창의적 인재 양성을 위한 다양한 교육 유형과 혁신 기술을 융합해, 학습관리부터 콘텐츠까지 교육의 가치를 제공합니다.",
  },
  data: {
    title: "Data Platform",
    lead: "방대한 데이터의 수집·저장·분석과 품질 관리를 상상스토리 플랫폼으로 일원화합니다.",
  },
  si: {
    title: "SI / SM",
    lead: "구축(SI) 및 유지관리(SM) 노하우와 기술력을 바탕으로 포털·업무시스템을 체계적으로 수행합니다.",
  },
  ai: {
    title: "AI Engine",
    lead: "독보적인 AI·머신러닝 엔진으로 교육과정 추천, 경영데이터 분석 등 의사결정을 지원합니다.",
  },
};

export const businessCertifications = [
  "상상 AI(인공지능)기반 LMS v2.0 — GS인증",
  "상상 데이터 종합관리 솔루션 v2.0 — GS인증",
  "기술혁신형 중소기업(Inno-Biz)",
  "벤처기업 · 기업부설연구소",
  "이러닝사업자 (한국에듀테크산업협회)",
];
