export const companyProfile = {
  legalName: "(주)상상스토리",
  formerNames: ["엠씨스소프트", "이데일리에듀"],
  founded: "2005.04.14",
  ceo: "김형섭",
  employees: "약 68명",
  capital: "1억 5,000만원",
  industry: "솔루션 · SI · CRM · ERP / EduTech · Data",
  mainBusiness: [
    "학습관리시스템(LMS) 및 교육 콘텐츠",
    "데이터 수집·품질·메타·분석 플랫폼",
    "SI / SM · 통합 포털",
    "AI 엔진 · 머신러닝",
  ],
} as const;

export const companyVision = {
  headline: "고객의 가치를 극대화하는 IT 파트너",
  body: "IT 기술력과 고객 산업에 대한 이해를 바탕으로 제조, 유통, 교육·미디어 분야 프로젝트의 구축과 운영을 성공적으로 수행해 왔습니다. 새로운 솔루션과 콘텐츠로 혁신적 성장 모델을 만들어, 비즈니스 환경에 맞는 IT 서비스로 고객의 발전을 지원합니다.",
  pillars: [
    {
      title: "EduTech Leadership",
      description:
        "2005년 LMS 개발 이후 GS인증 AI-LMS, 이러닝사업자로 교육 DX를 선도합니다.",
    },
    {
      title: "Data Trust",
      description:
        "수집·표준·품질·분석까지 데이터 종합관리로 신뢰 가능한 인사이트를 제공합니다.",
    },
    {
      title: "Delivery Excellence",
      description:
        "공공·금융·교육 SI/SM 노하우로 안정적인 구축과 장기 운영을 지원합니다.",
    },
  ],
} as const;

export type HistoryEvent = {
  year: string;
  title: string;
  description: string;
};

export const companyHistory: HistoryEvent[] = [
  {
    year: "2005",
    title: "창립 · LMS 사업 시작",
    description:
      "엠씨스소프트로 설립, LMS 솔루션 개발 착수. 한국직업능력개발원 우수 이러닝 교육과정 선정.",
  },
  {
    year: "2006–2008",
    title: "사업 영역 확장",
    description:
      "온라인 시스템·게임 분야 확장, LG 상남도서관·식품의약품안전청 등 교육 시스템 구축.",
  },
  {
    year: "2011",
    title: "R&D · 벤처 인증",
    description: "기업부설연구소 설립, 벤처기업 선정으로 기술 개발 체계 강화.",
  },
  {
    year: "2010s",
    title: "공공·금융 레퍼런스 확대",
    description:
      "한국거래소, 서민금융진흥원, 화학물질안전원 등 교육·포털 프로젝트 다수 수행.",
  },
  {
    year: "2020s",
    title: "AI · 데이터 플랫폼 고도화",
    description:
      "GS인증 AI-LMS·데이터 종합관리 v2.0, SS-AI Engine 등 통합 스택 완성. 미국(Tustin) 지사 운영.",
  },
  {
    year: "현재",
    title: "상상스토리",
    description:
      "EduTech · Data · SI/SM · AI를 아우르는 B2B IT 기업으로 성장, 글로벌 고객 협업 확대.",
  },
];

export const leadershipMessage = {
  role: "대표이사",
  name: companyProfile.ceo,
  quote:
    "온라인 교육의 본질은 편의성과 기회의 평등입니다. LMS와 데이터, AI 기술로 더 많은 학습자와 기관이 성장할 수 있도록 실질적인 가치를 만들겠습니다.",
  bio: "한양대 화학과 졸업, 경영정보시스템 박사. 2005년 상상스토리 창업 이후 LMS·데이터 품질·교육 시스템 분야 전문가로 활동.",
};
