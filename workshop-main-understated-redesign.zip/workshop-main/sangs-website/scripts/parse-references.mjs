import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const html = fs.readFileSync(path.join(__dirname, "reference.html"), "utf8");

const listMatch = html.match(/<div class="references_list">([\s\S]*?)<button class="btn_more"/);
if (!listMatch) {
  console.error("references_list not found");
  process.exit(1);
}

const listHtml = listMatch[1];
const chunks = listHtml.split('<div class="img_wrap">').slice(1);
const items = [];

for (const chunk of chunks) {
  const imgPc =
    chunk.match(
      /src="(https:\/\/www\.sangs\.co\.kr\/theme\/sangsangstory\/ko\/images\/ref_new\/reference_new_[^"]+)"/
    )?.[1] ?? "";

  const imgMo =
    chunk.match(/class="img_mo"[^>]*src="([^"]+)"/)?.[1] ??
    chunk.match(/src="([^"]+)"[^>]*class="img_mo"/)?.[1];

  const txtMatch = chunk.match(/<div class="txt_wrap">([\s\S]*)/);
  if (!txtMatch) continue;
  const txt = txtMatch[1];

  const categoryClass =
    txt.match(/class="category (\w+)"/)?.[1] ??
    txt.match(/class="category\s+(\w+)"/)?.[1];
  if (!categoryClass) continue;

  const title = txt
    .match(/<p class="title">\s*([\s\S]*?)<\/p>/)?.[1]
    ?.replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();

  const bullets = [];
  const ulInner = txt.match(/<ul>([\s\S]*?)<\/ul>/)?.[1];
  if (ulInner) {
    for (const b of ulInner.matchAll(/<li>([\s\S]*?)<\/li>/g)) {
      const text = b[1].replace(/<[^>]+>/g, "").trim();
      if (text) bullets.push(text);
    }
  }

  const tags = txt.match(/<p class="tag">([^<]*)<\/p>/)?.[1]?.trim();

  const idMatch = imgPc.match(/reference_new_(\d+)/);
  const id = idMatch ? `ref-${idMatch[1]}` : `ref-${items.length + 1}`;

  items.push({
    id,
    category: categoryClass,
    imagePc: imgPc,
    ...(imgMo ? { imageMo: imgMo } : {}),
    title: title ?? "",
    bullets,
    ...(tags ? { tags } : {}),
  });
}

const outPath = path.join(__dirname, "..", "src", "config", "references.json");
fs.writeFileSync(outPath, JSON.stringify(items, null, 2), "utf8");
console.log(`Wrote ${items.length} references to ${outPath}`);
